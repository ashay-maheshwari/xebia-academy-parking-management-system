<?php
error_reporting(E_ALL);
ini_set('display_errors', 'on');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header("Content-type: text/html; charset=iso-8859-1");header("Content-type: text/html; charset=iso-8859-1");




session_start();
 
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: http://nmcn.ernet.in/login.php");
  exit;
}


$db_host = 'localhost'; // Server Name
$db_user = 'root'; // Username
$db_pass = 'vlead123'; // Password
$db_name = 'nmcn_dashboard'; // Database Name

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
	die ('Failed to connect to MySQL: ' . mysqli_connect_error());	
}



//Add queries for every search here
// echo $_POST['querylist']

$id = $_GET['college-id'] ;

$sql = 'SELECT  college_id, name_of_college, state, zone,nodal_officer,site_preparation,hardware_delivery,hardware_installation,integration,capacity_building,uat,go_live,manpower  FROM college_info where college_id='.$id.';';
        $query = mysqli_query($conn, $sql);

$no 	= 1;
$total 	= 0;
$site_preparation = "";
$hardware_delivery = "";
$hardware_installation = "";
$integration = "";
$uat = "";
$go_live = "";
$capacity_building = "" ;
$manpower = "";
while ($row = mysqli_fetch_array($query))
{
	$site_preparation = $row["site_preparation"];
	$hardware_delivery = $row["hardware_delivery"];
	$hardware_installation = $row["hardware_installation"];
	$integration = $row["integration"];
	$uat = $row["uat"];
	$go_live = $row["go_live"];
	$capacity_building = $row["capacity_building"];
	$manpower = $row["manpower"];
        
	
}



$id = $_GET['college-id'] ;
$sql = 'SELECT  college_id, name_of_college, state, zone,nodal_officer,site_preparation,hardware_delivery,hardware_installation, integration, capacity_building, uat, go_live,manpower FROM college_info where college_id='.$id.';';
        $query = mysqli_query($conn, $sql);





if (!$query) {
	die ('SQL Error: ' . mysqli_error($conn));
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<title>NMCN 2.0</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="style.css" type="text/css" rel="stylesheet">
<style>


* {
    box-sizing: border-box;
}

.headercolumn1 {
float: left;
    width: 15%;
    padding: 10px;
    height: 100px; /* Should be removed. Only for demonstration */
}

.headercolumn2 {
float: left;
    width: 70%;
    padding: 10px;
    height: 100px; /* Should be removed. Only for demonstration */
}

.statuscolumn1 {
float: left;
    width: 45%;
    padding: 10px;
    height: 500px; /* Should be removed. Only for demonstration */
}
.statuscolumn2 {
float: left;
    width: 45%;
    padding: 10px;
    height: 500px; /* Should be removed. Only for demonstration */
}

.headercolumn3 {
float: left;
    width: 15%;
    padding: 10px;
    height: 100px; /* Should be removed. Only for demonstration */
}



* {
    box-sizing: border-box;
}

body {
  margin: 0;
}

/* Style the header */
.header {
    background-color: #f1f1f1;
    padding: 20px;
    text-align: center;
	width="100%";
	height="20%";
	
}

/* Style the top navigation bar */
.topnav {
    overflow: hidden;
	
    
}

/* Style the topnav links */
.topnav a {
    float: left;
    display: block;
    color: white;
    text-align: center;
    padding: 14px 65px;
	/*background-color: #6666ff;*/
    text-decoration: none;
}

/* Change color on hover */
.topnav a:hover {
    background-color: #ddd;
    color: black;
	
}

/* Create three equal columns that floats next to each other */
.column {
    float: left;
    width: 33.33%;
    padding: 15px;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
@media screen and (max-width:600px) {
    .column {
        width: 100%;
    }
}





* {
    box-sizing: border-box;
}

/* Create two equal columns that floats next to each other */
.column1 {
    float: left;
    width: 38%;
    padding: 10px;
    height: 600px; /* Should be removed. Only for demonstration */
}

.column2 {
    float: right;
    width: 60%;
    padding: 10px;
    height: 600px; /* Should be removed. Only for demonstration */
}


/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .column {
        width: 100%;
    }
}

* {
    box-sizing: border-box;
}

body {
  margin: 0;
}

/* Style the header */
.header {
    background-color: #f1f1f1;
    padding: 20px;
    text-align: center;
	width:100%;
	
	
}

/* Style the top navigation bar */
.topnav {
    overflow: hidden;
	
    
}

/* Style the topnav links */

/* Change color on hover */
.topnav a:hover {
    background-color: #ddd;
    color: black;
	
}

/* Create three equal columns that floats next to each other */
.column {
    float: left;
    width: 33.33%;
    padding: 15px;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
@media screen and (max-width:600px) {
    .column {
        width: 100%;
    }
}


* {box-sizing: border-box}
body {font-family: Verdana, sans-serif; margin:0}
.mySlides {display: none}
img {vertical-align: middle;width:100%}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
*/  background-color: rgba(0,0,0,0.8);*/
}

/* Caption text */
.text {
  
  color:white;
  font-size: 35px;
  padding: 18px 12px;
  position: fixed;
  bottom: 8px;
  width: 70%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  /*color: #f2f2f2; */
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .prev, .next,.text {font-size: 11px}
}


</style>


<script>
	var college_id = '<?php echo $id?>';
	var site_preparation = '<?php echo $site_preparation?>';
	var hardware_delivery = '<?php echo $hardware_delivery?>';
	var hardware_installation = '<?php echo $hardware_installation?>';
	var integration = '<?php echo $hardware_installation?>';
	var capacity_building = '<?php echo $capacity_building?>';
	var uat = '<?php echo $uat?>';
	var go_live = '<?php echo $go_live?>';

	var site_value = 0;
	var delivery_value = 0;
	var installation_value = 0;
	var integration_value = 0;
	var capacity_building_value = 0;
	var uat_value = 0;
	var go_live_value = 0;

	if (site_preparation == "Completed") 
		{
			var site_value = 10;
		}

	if (hardware_delivery == "Delivered") 
                {
                        var delivery_value = 10;
                }


  	if (hardware_installation == "Installed") 
                {
                        var installation_value = 10;
                }


        if (hardware_installation == "Installed") 
                {
                        var installation_value = 10;
                }


	if (integration == "Completed")
		{
			var integration_value = 10;
		}

	if (capacity_building == "Completed")
		{
			var capacity_building_value = 5;
		}

	if (uat == "Completed") 
		{
			var uat_value = 10;
		}


	if (go_live == "Completed")
		{
			var go_live_value = 10;
		}

	var activity_value = 100 - 20 - 5 - site_value - delivery_value - installation_value - capacity_building_value - uat_value - go_live_value;
	var theLink = "http://nmcn.ernet.in/reports/college-"+ college_id +".pdf"; 
	window.onload = function() {
	var chart = new CanvasJS.Chart("chartContainer", {
        	animationEnabled: true,
	        title: {
        	        text: "Overall activity completion status of this college"
	        },
                
        	data: [{
                	type: "pie",
	                startAngle: 240,
        	        yValueFormatString: "##0.00\"%\"",
                	indexLabel: "{label} {y}",
                                
	                dataPoints: [
        	                {y: 20, label: "Site Survey Completed", link: theLink},
                	        {y: activity_value, label: "Activities to be completed"},
                        	{y: 5, label: "Site Survey report submitted", link: theLink},
                        	{y: site_value, label: "Site Preparation", link: theLink},
                        	{y: delivery_value, label: "Hardware Delivery ", link: theLink},
                        	{y: installation_value, label: "Hardware Installation ", link: theLink},
                        	{y: integration_value, label: "Integration ", link: theLink},
                        	{y: capacity_building_value, label: "Capacity Building ", link: theLink},
                        	{y: uat_value, label: "Go-Live Sign-Off ", link: theLink},
                        	{y: go_live_value, label: "Go Live ", link: theLink}
        		        ]
	    	    }]
});
	chart.options.data[0].click = function(e){ 
	    var dataSeries = e.dataSeries;
	    var dataPoint = e.dataPoint;
	    var dataPointIndex = e.dataPointIndex;
    
	    if(1)
        	window.open(dataPoint.link,'_blank');  
    
	    for(var i = 0; i < dataSeries.dataPoints.length; i++){
        	    if(i === dataPointIndex){                
                	continue;
	            }
        	    
            	dataSeries.dataPoints[i].exploded = false;            
    		}
	};
		chart.render();
	}

</script>


</head>
<body>





<div class="row">
  <div class="headercolumn1" style="background-color: #ffffff">
    <a href="http://www.ernet.in/" target="_blank"><img src="images/ernet.png"  style="height:75px;width:115px;"/></a>
        
  </div>
  <div class="headercolumn2" style="background-color: #ffffff">
</br>
    <h2 style="color:black;text-align: center">Dashboard for monitoring e-Classroom infrastructure in 50 Medical Colleges</h2>
  </div>
  <div class="headercolumn3" style="background-color: #ffffff">
<a href="http://www.yash.com" target="_blank" ><img src="images/yash.png" style="height:90px;width:135px;float: right;"/></a>
  </div>
</div>


<div class="topnav" style="align-content: center;">

  <a href="http://nmcn.ernet.in/about.php">Home</a>
  <a href="http://nmcn.ernet.in/logout.php">Logout</a> 
  
</div>

</br>

<h1 style="text-align:center;color:white">Details of College</h1>

<h6 style="text-align:center;color:white">(click college name to view survey report)</h6>
</br>
	<table bordercolor="white" border="1" cellspacing="15">



<thead>
			<tr>
				<th>College ID</th>
				<th>Name of College</th>
				<th>State</th>
				<th>Zone Category</th>
				<th>Name of Nodal Officer</th>
				<th>Site Preparation Status</th>
				<th>Hardware Delivery Status</th>
				<th>Hardware Installation Status</th>
				<th>Integration</th>
				<th>Capacity_building</th>
				<th>Go-Live Sign-Off</th>
				<th>Go Live</th>
			</tr>
		</thead>
		<tbody>
		<?php
		$no 	= 1;
		$total 	= 0;
		while ($row = mysqli_fetch_array($query))
		{
			$id_val = $row["college_id"];
		//	$amount  = $row['amount'] == 0 ? '' : number_format($row['amount']);
			echo "<tr>
					<td>".$row["college_id"]."</td>
					<td><a target='_blank' href='http://nmcn.ernet.in/reports/college-$id_val.pdf'>".$row["name_of_college"]."</td>
					<td>".$row["state"]."</td>
					<td>".$row["zone"]."</td>
					<td>".$row["nodal_officer"]."</td>
					<td>".$row["site_preparation"]."</td>
					<td>".$row["hardware_delivery"]."</td>
					<td>".$row["hardware_installation"]."</td>
					<td>".$row["integration"]."</td>
					<td>".$row["capacity_building"]."</td>
					<td>".$row["uat"]."</td>
					<td>".$row["go_live"]."</td>
				</tr>";
//			$total += $row['amount'];
//			$no++;
		}?>
		</tbody>
	</table>

</br>
</br>
</br>

<div class="row">
  <div class="statuscolumn1" >
<h2 style="text-align:center;color:white">Task Completion status</h2>

<?php 
	
if ($site_preparation == "Completed")
{
	$site_tick_value = "&#10004;";
} else 
	{
	$site_tick_value = "&#10006;";
}


if ($hardware_delivery == "Delivered")
{
        $delivery_tick_value = "&#10004;";
} else
        {
        $delivery_tick_value = "&#10006;";
}


if ($hardware_installation == "Installed")
{
        $installation_tick_value = "&#10004;";
} else
        {   
        $installation_tick_value = "&#10006;";
}

if ($integration == "Completed")
{
        $integration_tick_value = "&#10004;";
} else
        {
        $integration_tick_value = "&#10006;";
}

if ($uat == "Completed")
{
        $uat_tick_value = "&#10004;";
} else
        {
        $uat_tick_value = "&#10006;";
}


if ($capacity_building == "Completed")
{
        $capacity_building_tick_value = "&#10004;";
} else
        {
        $capacity_building_tick_value = "&#10006;";
}

if ($go_live == "Completed")
{
        $go_live_tick_value = "&#10004;";
} else
        {
        $go_live_tick_value = "&#10006;";
}

if ($manpower == "Deployed")
{
	$manpower_tick_value = "&#10004;";
} else 
	{
	$manpower_tick_value = "&#10006;";
}

echo
		
'<table align="left" cellspacing="25"> <th>S.No.</th> <th>Activity</th> <th>Completion Status</th>
 <tr><td>1</td><td>Site Survey</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">&#10004;</td></tr>
 <tr><td>2</td><td>Site Survey Report Submitted</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">&#10004;</td></tr>
 <tr><td>3</td><td>Site Preparation</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">'.$site_tick_value.'</td></tr>
 <tr><td>4</td><td>Delivery of Hardware/Software</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">'.$delivery_tick_value.'</td></tr>
 <tr><td>5</td><td>Hardware Installation</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">'.$installation_tick_value.'</td></tr>
 <tr><td>6</td><td>Integration</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">'.$integration_tick_value.'</td></tr>
 <tr><td>7</td><td>Capacity Building / Training</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">'.$capacity_building_tick_value.'</td></tr>
 <tr><td>8</td><td>Go-Live Sign-Off</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">'.$uat_tick_value.'</td></tr>
 <tr><td>9</td><td>Go Live</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">'.$go_live_tick_value.'</td></tr>
 <tr><td>10</td><td>Deployment of Manpower for O&M</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">'.$manpower_tick_value.'</td></tr>
</table>';

?>

</br>
</br>
</br>

</br>
</div>

<!--center>
  <div id="chartContainer" style="height: 400px; width: 90%;">
  </div>
</center>
</br--!>
</br>
</br>

	<div class="statuscolumn2" style="background-color: #ffffff;margin-right:20px;">
	<div id="chartContainer" style="height: 450px; width: 100%;"></div>
	<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
	</div>
	</div>
</br>
</br>
</br>
</br>


<div style="height: 80px;width: 100%;postion:absolute;bottom:0">
</br>
</br>
</br>
</br>
</br>
</br>
</br>
</br>
<h5 style="text-align:center">Designed By:- ERNET India, 5th Floor, Block-I, A Wing, DMRC IT Park Shastri Park, Delhi-110053</h5>

</div>




</body>
</html>

