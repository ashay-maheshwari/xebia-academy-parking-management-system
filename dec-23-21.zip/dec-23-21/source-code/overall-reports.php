<!DOCTYPE html>

<html lang="en">
<head>
<title>NMCN 2.0</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="style.css" type="text/css" rel="stylesheet">


<style>


* {
    box-sizing: border-box;
}

.headercolumn1 {
float: left;
    width: 15%;
    padding: 10px;
    height: 100px; /* Should be removed. Only for demonstration */
}

.headercolumn2 {
float: left;
    width: 70%;
    padding: 10px;
    height: 100px; /* Should be removed. Only for demonstration */
}

.headercolumn3 {
float: left;
    width: 15%;
    padding: 10px;
    height: 100px; /* Should be removed. Only for demonstration */
}



* {
    box-sizing: border-box;
}

body {
  margin: 0;
}

/* Style the header */
.header {
    background-color: #f1f1f1;
    padding: 20px;
    text-align: center;
	width="100%";
	height="20%";
	
}

/* Style the top navigation bar */
.topnav {
    overflow: hidden;
	
    
}

/* Style the topnav links */
.topnav a {
    float: left;
    display: block;
    color: white;
    text-align: center;
    padding: 14px 107px;
	/*background-color: #6666ff;*/
    text-decoration: none;
}

/* Change color on hover */
.topnav a:hover {
    background-color: #ddd;
    color: black;
	
}

/* Create three equal columns that floats next to each other */
.column {
    float: left;
    width: 33.33%;
    padding: 15px;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
@media screen and (max-width:600px) {
    .column {
        width: 100%;
    }
}





* {
    box-sizing: border-box;
}

/* Create two equal columns that floats next to each other */
.column1 {
    float: left;
    width: 48%;
    background-color:#ed5f6b;
    padding: 10px;
    height: 400px; /* Should be removed. Only for demonstration */
}


.tablecolumn1 {
    float: left;
    width: 50%;
    background-color:#ed5f6b;
    padding: 10px;
    height: 450px; /* Should be removed. Only for demonstration */
}


.tablecolumn2 {
    float: left;
    width: 50%;
    background-color:#ed5f6b;
    padding: 10px;
    height: 450px; /* Should be removed. Only for demonstration */
}

.btn-1 {
    float: left;
    width: 14%; 
    background-color: #ed5f6b;
    border-style:solid;
    padding: 10px;
 /*   vertical-align: middle;*/
    height: 80px;
}
	

.column2 {
    float: right;
    width: 45%;
    background-color:#ed5f6b;
    padding: 10px;
    height: 400px; /* Should be removed. Only for demonstration */
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .column {
        width: 100%;
    }
}

* {
    box-sizing: border-box;
}

body {
  margin: 0;
}

/* Style the header */
.header {
    background-color: #f1f1f1;
    padding: 20px;
    text-align: center;
	width:100%;
	
	
}

/* Style the top navigation bar */
.topnav {
    overflow: hidden;
	
    
}

/* Style the topnav links */
.topnav a {
    float: left;
    display: block;
    color: white;
    text-align: center;
    padding: 14px 80px;
	/*background-color: #6666ff;*/
    text-decoration: none;
}

/* Change color on hover */
.topnav a:hover {
    background-color: #ddd;
    color: black;
	
}

/* Create three equal columns that floats next to each other */
.column {
    float: left;
    width: 33.33%;
    padding: 15px;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
@media screen and (max-width:600px) {
    .column {
        width: 100%;
    }
}


* {box-sizing: border-box}
body {font-family: Verdana, sans-serif; margin:0}
.mySlides {display: none}
img {vertical-align: middle;width:100%}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
*/  background-color: rgba(0,0,0,0.8);*/
}

/* Caption text */
.text {
  
  color:white;
  font-size: 35px;
  padding: 18px 12px;
  position: fixed;
  bottom: 8px;
  width: 70%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  /*color: #f2f2f2; */
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .prev, .next,.text {font-size: 11px}
}


</style>

</head>
<body>

<div class="row">
  <div class="headercolumn1" style="background-color: #ffffff">
    <a href="http://www.ernet.in/" target="_blank"><img src="images/ernet.png"  style="height:75px;width:115px;" /></a>
    
  </div>
  <div class="headercolumn2" style="background-color: #ffffff">
</br>
    <h2 style="color:black;text-align: center">Dashboard for monitoring e-Classroom infrastructure in 50 Medical Colleges</h2>
  </div>
  <div class="headercolumn3" style="background-color: #ffffff">
<a href="http://www.yash.com" target="_blank" ><img src="images/yash.png" style="height:90px;width:135px;float: right;"/></a>
  </div>
</div>


<div class="topnav" style="align-content: center;">

  <a href="http://nmcn.ernet.in/about.php">Home</a>
  <a href="http://nmcn.ernet.in/page-3.php">Reports</a>
<a href="http://nmcn.ernet.in/page-4.php" target="_blank">Project Documents</a>

  <a href="http://nmcn.ernet.in/logout.php">Logout</a>
</div>

</br>

	</div>
</div>

</br>
<h1 style="text-align:center">Overall Reports</h1>

<div class="row" style="background-color:#ed5f6b;">
  <div class="column1" >
<iframe src="activity-dashboard.php" style="height: 400px; width: 100%;background-color:#ed5f6b;" align="center" frameBorder="0"></iframe></p>
  </div>
  <div class="column3" style="background-color:#EEEEE;">
</br>
<table class="" bordercolor="white" border="1" cellspacing="15">
		

		<thead>
			<tr>
				<th colspan="5" align="center" style="text-align:center;">Overall Project Status</th>
			</tr>
			<tr>
				<th>S.No.</th>
				<th>Activity</th>
				<th>Allocated Percentage(%)</th>
				<th>Completed Percentage(%)</th>
				
			</tr>
			
				
		</thead>
		<tbody>
			<tr>
				<td>1</td>
				<td>Site Survey </td>
				<td>20%</td>
				<td>100%</td>
				
			</tr>

			<tr>
				<td>2</td>
				<td>Site Survey Report Submitted</td>
				<td>5%</td>
				<td>100%</td>
				
			</tr>	

			<tr>
				<td>3</td>
				<td>Site Preparation</td>
				<td>10%</td>
 			    <td>100.00%</th>	
			</tr>	

			
			
						
						
						<tr>
								<td>4</td>
                                <td>Delivery of Hardware/Software</td>
                                <td>10%</td>
                                <td>100%</td>
                                
						</tr>
						
						<tr>
								<td>5</td>
                                <td>Hardware Installation</td>
                                <td>10%</td>
                                
                                <th>100%</th>
						</tr>
						
						<tr>
								<td>6</td>
                                <td>Integration</td>
                                <td>10%</td>
                                <th>96%</th>
						</tr>
						
						<tr>
								<td>7</td>
                                <td>Capacity Building/Training</td>
                                <td>5%</td>
                                <td>100%</td>
                                
						</tr>
						
						<tr>
								<td>8</td>
                                <td>Go-Live Sign-Off</td>
                                <td>10%</td>
                                <th>96%</th>
						</tr>
						
						<tr>
								<td>9</td>
                                <td>Go Live</td>
                                <td>10%</td>
                                
                                <th>96%</th>
						</tr>
						
						<tr>
								<td>10</td>
                                <td>Deployment of Manpower for O&M</td>
                                <td>10%</td>
                                
                                <th>100%</th>
						</tr>

						<tr>
								<td></td>
                                <td>Total</td>
                                <td>100%</td>
                                
                                <th></th>
						</tr>
			
			
		</tbody>
	</table>


  </div>
</div>

</br></br>
	


</br>
</br>
Designed By:- ERNET India, 5th Floor, Block-I, A Wing, DMRC IT Park Shastri Park, Delhi-110053



</body>
</html>


