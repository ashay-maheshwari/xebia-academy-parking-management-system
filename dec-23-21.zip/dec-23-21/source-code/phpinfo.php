<?php phpinfo( ); ?>


