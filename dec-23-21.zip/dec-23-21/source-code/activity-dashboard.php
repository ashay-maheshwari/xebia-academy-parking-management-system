<!DOCTYPE HTML>
<html>
<head>  
<script>
window.onload = function () {
	
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	
	title:{
		text:"Activity Dashboard (Overall in No. of Colleges)"
	},
	axisX:{
		interval: 1
	},
	axisY2:{
		interlacedColor: "rgba(1,77,101,.2)",
		gridColor: "rgba(1,77,101,.1)",
		maximum: 50,
		minimum:0,
		title: ""
	},
	data: [{
		type: "bar",
		name: "companies",
		axisYType: "secondary",
		color: "#014D65",
		indexLabelPlacement: "outside",
		click: function(xaxis){
			var datapoint_name = xaxis.dataPoint.label;
			if (datapoint_name == "Site Survey") {
			window.open("http://nmcn.ernet.in/list-all.php", "_blank")
			}
			if (datapoint_name == "Site Survey Reports Submitted") {
                        window.open("http://nmcn.ernet.in/list-all.php", "_blank")
                        }		

                        if (datapoint_name == "Site Preparation") {
                        window.open("http://nmcn.ernet.in/site-preparation.php", "_blank")
                        }  			

	                if (datapoint_name == "Delivery of Hardware and Software") {
                        window.open("http://nmcn.ernet.in/hardware-delivery.php", "_blank")
                        } 
		       if (datapoint_name == "Hardware Installation") {
                        window.open("http://nmcn.ernet.in/hardware-installation.php", "_blank")
                        } 

       if (datapoint_name == "Integration") {
                        window.open("http://nmcn.ernet.in/integration.php", "_blank")
                        }
       if (datapoint_name == "Capacity Building / Training") {
                        window.open("http://nmcn.ernet.in/capacity_building.php", "_blank")
                        }
       if (datapoint_name == "Go-Live Sign-Off") {
                        window.open("http://nmcn.ernet.in/uat.php", "_blank")
                        }
       if (datapoint_name == "Go-Live") {
                        window.open("http://nmcn.ernet.in/go_live.php", "_blank")
                        }
  if (datapoint_name == "Deployment of Manpower") {
                        window.open("http://nmcn.ernet.in/manpower.php", "_blank")
                        }

		}, 
		dataPoints: [
        	{  y: 50, label: "Deployment of Manpower",indexLabel:"50"},
		{  y: 49, label: "Go-Live",indexLabel:"49"},
		{  y: 49, label: "Go-Live Sign-Off",indexLabel:"49"},
		{  y: 49, label: "Capacity Building / Training",indexLabel:"49"},
		{  y: 49, label: "Integration",indexLabel:"49"},
		{  y: 49, label: "Hardware Installation",indexLabel:"49"},
		{  y: 49, label: "Delivery of Hardware and Software",indexLabel:"49" },
		{  y: 49, label: "Site Preparation",indexLabel:"49"},
		{  y: 50, label: "Site Survey Reports Submitted",indexLabel:"50" },
		{  y: 50 , label: "Site Survey",indexLabel:"50"}
		]
	}]
});
chart.render();

}
</script>
</head>
<body>
<div id="chartContainer" style="height: 380px; width: 100%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</body>
</html>
