<!DOCTYPE html>
<html lang="en">
<head>
<title>NMCN 2.0</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<script type="text/javascript">
  window.onload = function () {
    var chart = new CanvasJS.Chart("chartContainer",
    {
      width:700,
      title:{
      text: "Dashboard Graphical View (Overall)"
      },

      axisY:{
		title:"Percent of Activity",
		maximum: 100,
	},
      axisX:{
		title:"Activities",
		labelFontSize: 10,
	},
        data: [
		
		//first Bar for Site Survey Conducted 
      {
	indexLabelPlacement: "outside",
	click: function(xaxis){
	var datapoint_name = xaxis.dataPoint.label;
},
        type: "stackedColumn",
        legendText: "Activity completed",
     	showInLegend: "true",
	color: "green",
        dataPoints: [
        {  y: 100 , label: "Site Survey conducted",indexLabel:"100%"},
        {  y: 100, label: "Site Survey Report submitted",indexLabel:"100%" },
	{  y: 100, label: "Site Preparation",indexLabel:"100%"},
        {  y: 100, label: "Delivery of Hardware and Software",indexLabel:"100%" },
	{  y: 100, label: "Hardware Installation",indexLabel:"100%"},
	{  y: 100, label: "Integration",indexLabel:"100%"},
	{  y: 1000, label: "Capacity Building / Training",indexLabel:"100%"},
	{  y: 100, label: "Go-Live Sign-Off",indexLabel:"100%"},
	{  y: 100, label: "Go-Live",indexLabel:"100%"},
	{  y: 100, label: "Deployment of Manpower for Operations and Maintenance",indexLabel:"100%"}
        ]
      },  
	  
      ]
    });

    chart.render();
  }


  </script>

<script type="text/javascript" src="https://canvasjs.com/assets/script/canvasjs.min.js"></script></head>

<style>


* {
    box-sizing: border-box;
}

.headercolumn1 {
float: left;
    width: 15%;
    padding: 10px;
    height: 100px; /* Should be removed. Only for demonstration */
}

.headercolumn2 {
float: left;
    width: 70%;
    padding: 10px;
    height: 100px; /* Should be removed. Only for demonstration */
}

.headercolumn3 {
float: left;
    width: 15%;
    padding: 10px;
    height: 100px; /* Should be removed. Only for demonstration */
}



* {
    box-sizing: border-box;
}

body {
  margin: 0;
}

/* Style the header */
.header {
    background-color: #f1f1f1;
    padding: 20px;
    text-align: center;
	width="100%";
	height="20%";
	
}

/* Style the top navigation bar */
.topnav {
    overflow: hidden;
	
    
}

/* Style the topnav links */
.topnav a {
    float: left;
    display: block;
    color: white;
    text-align: center;
    padding: 14px 45px;

	/*background-color: #6666ff;*/
    text-decoration: none;
}

/* Change color on hover */
.topnav a:hover {
    background-color: #ddd;
    color: black;
	
}

/* Create three equal columns that floats next to each other */
.column {
    float: left;
    width: 33.33%;
    padding: 15px;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
@media screen and (max-width:600px) {
    .column {
        width: 100%;
    }
}





* {
    box-sizing: border-box;
}

/* Create two equal columns that floats next to each other */
.column1 {
    float: left;
    width: 38%;
    padding: 10px;
    height: 600px; /* Should be removed. Only for demonstration */
}

.column2 {
    float: right;
    width: 60%;
    padding: 10px;
    height: 600px; /* Should be removed. Only for demonstration */
}


/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .column {
        width: 100%;
    }
}

* {
    box-sizing: border-box;
}

body {
  margin: 0;
}

/* Style the header */
.header {
    background-color: #f1f1f1;
    padding: 20px;
    text-align: center;
	width:100%;
	
	
}

/* Style the top navigation bar */
.topnav {
    overflow: hidden;
	
    
}

/* Style the topnav links */

/* Change color on hover */
.topnav a:hover {
    background-color: #ddd;
    color: black;
	
}

/* Create three equal columns that floats next to each other */
.column {
    float: left;
    width: 33.33%;
    padding: 15px;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
@media screen and (max-width:600px) {
    .column {
        width: 100%;
    }
}


* {box-sizing: border-box}
body {font-family: Verdana, sans-serif; margin:0}
.mySlides {display: none}
img {vertical-align: middle;width:100%}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
*/  background-color: rgba(0,0,0,0.8);*/
}

/* Caption text */
.text {
  
  color:white;
  font-size: 35px;
  padding: 18px 12px;
  position: fixed;
  bottom: 8px;
  width: 70%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  /*color: #f2f2f2; */
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .prev, .next,.text {font-size: 11px}
}


</style>
</head>
<body>








</br>
  <div id="chartContainer" style="align-content:center;height: 400px; ">  </div>



</br>





</body>
</html>


