<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header("Content-type: text/html; charset=iso-8859-1");header("Content-type: text/html; charset=iso-8859-1");




session_start();
 
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: login.php");
  exit;
}



$db_host = 'localhost'; // Server Name
$db_user = 'root'; // Username
$db_pass = 'vlead123'; // Password
$db_name = 'nmcn_dashboard'; // Database Name

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
	die ('Failed to connect to MySQL: ' . mysqli_connect_error());	
}



//Add queries for every search here
// echo $_POST['querylist']


$id = $_POST['querylist5'];

if ($_POST['querylist5'] == "1")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=1';
        $query = mysqli_query($conn, $sql);
} //Seating capacity less than 50



if ($_POST['querylist5'] == "2")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer ,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=2';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "3")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=3';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "4")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=4';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "5")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=5';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "6")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=6';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "7")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=7';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "8")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=8';
        $query = mysqli_query($conn, $sql);
} 



if ($_POST['querylist5'] == "9")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=9';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "10")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=10';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "11")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=11';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "12")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=12';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "13")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=13';
        $query = mysqli_query($conn, $sql);
} 

if ($_POST['querylist5'] == "14")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=14';
        $query = mysqli_query($conn, $sql);
}


if ($_POST['querylist5'] == "15")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=15';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "16")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=16';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "17")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=17';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "18")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=18';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "19")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=19';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "20")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=20';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "21")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=21';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "22")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=22';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "23")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=23';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "24")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=24';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "25")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=25';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "26")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=26';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "27")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=27';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "28")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=28';
        $query = mysqli_query($conn, $sql);
} 

if ($_POST['querylist5'] == "29")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where c
ollege_id=29';
        $query = mysqli_query($conn, $sql);
} 

if ($_POST['querylist5'] == "30")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=30';
        $query = mysqli_query($conn, $sql);
}


if ($_POST['querylist5'] == "31")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=31';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "32")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=32';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "33")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=33';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "34")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=34';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "35")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=35';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "36")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=36';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "37")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=37';
        $query = mysqli_query($conn, $sql);
} 

if ($_POST['querylist5'] == "38")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=38';
        $query = mysqli_query($conn, $sql);
} 

if ($_POST['querylist5'] == "39")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=39';
        $query = mysqli_query($conn, $sql);
} 

if ($_POST['querylist5'] == "40")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=40';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "41")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=41';
        $query = mysqli_query($conn, $sql);
} 

if ($_POST['querylist5'] == "42")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=42';
        $query = mysqli_query($conn, $sql);
} 

if ($_POST['querylist5'] == "43")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=43';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "44")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=44';
        $query = mysqli_query($conn, $sql);
} 

if ($_POST['querylist5'] == "45")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=45';
        $query = mysqli_query($conn, $sql);
} 

if ($_POST['querylist5'] == "46")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=46';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "47")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=47';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "48")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=48';
        $query = mysqli_query($conn, $sql);
} 


if ($_POST['querylist5'] == "49")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=49';
        $query = mysqli_query($conn, $sql);
} 

if ($_POST['querylist5'] == "50")
{
$sql = 'SELECT  college_id, name_of_college, state, zone, rrc_or_normal, nodal_officer,site_survey_status,site_survey_report_status,site_preparation  FROM college_info where college_id=50';
        $query = mysqli_query($conn, $sql);
} 



if (!$query) {
	die ('SQL Error: ' . mysqli_error($conn));
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<title>NMCN 2.0</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="style.css" type="text/css" rel="stylesheet">
<style>


* {
    box-sizing: border-box;
}

.headercolumn1 {
float: left;
    width: 15%;
    padding: 10px;
    height: 100px; /* Should be removed. Only for demonstration */
}

.headercolumn2 {
float: left;
    width: 70%;
    padding: 10px;
    height: 100px; /* Should be removed. Only for demonstration */
}

.statuscolumn1 {
float: left;
    width: 45%;
    padding: 10px;
    height: 500px; /* Should be removed. Only for demonstration */
}
.statuscolumn2 {
float: left;
    width: 45%;
    padding: 10px;
    height: 500px; /* Should be removed. Only for demonstration */
}

.headercolumn3 {
float: left;
    width: 15%;
    padding: 10px;
    height: 100px; /* Should be removed. Only for demonstration */
}



* {
    box-sizing: border-box;
}

body {
  margin: 0;
}

/* Style the header */
.header {
    background-color: #f1f1f1;
    padding: 20px;
    text-align: center;
	width="100%";
	height="20%";
	
}

/* Style the top navigation bar */
.topnav {
    overflow: hidden;
	
    
}

/* Style the topnav links */
.topnav a {
    float: left;
    display: block;
    color: white;
    text-align: center;
    padding: 14px 65px;
	/*background-color: #6666ff;*/
    text-decoration: none;
}

/* Change color on hover */
.topnav a:hover {
    background-color: #ddd;
    color: black;
	
}

/* Create three equal columns that floats next to each other */
.column {
    float: left;
    width: 33.33%;
    padding: 15px;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
@media screen and (max-width:600px) {
    .column {
        width: 100%;
    }
}





* {
    box-sizing: border-box;
}

/* Create two equal columns that floats next to each other */
.column1 {
    float: left;
    width: 38%;
    padding: 10px;
    height: 600px; /* Should be removed. Only for demonstration */
}

.column2 {
    float: right;
    width: 60%;
    padding: 10px;
    height: 600px; /* Should be removed. Only for demonstration */
}


/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .column {
        width: 100%;
    }
}

* {
    box-sizing: border-box;
}

body {
  margin: 0;
}

/* Style the header */
.header {
    background-color: #f1f1f1;
    padding: 20px;
    text-align: center;
	width:100%;
	
	
}

/* Style the top navigation bar */
.topnav {
    overflow: hidden;
	
    
}

/* Style the topnav links */

/* Change color on hover */
.topnav a:hover {
    background-color: #ddd;
    color: black;
	
}

/* Create three equal columns that floats next to each other */
.column {
    float: left;
    width: 33.33%;
    padding: 15px;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
@media screen and (max-width:600px) {
    .column {
        width: 100%;
    }
}


* {box-sizing: border-box}
body {font-family: Verdana, sans-serif; margin:0}
.mySlides {display: none}
img {vertical-align: middle;width:100%}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
*/  background-color: rgba(0,0,0,0.8);*/
}

/* Caption text */
.text {
  
  color:white;
  font-size: 35px;
  padding: 18px 12px;
  position: fixed;
  bottom: 8px;
  width: 70%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  /*color: #f2f2f2; */
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .prev, .next,.text {font-size: 11px}
}


</style>


<script>
var bool = "<?php echo $id?>"
if (bool == "1") 
{ 
	var theLink = "http://nmcn.ernet.in/reports/college-1.pdf"; 
}

if (bool == "2") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-2.pdf"; 
}

if (bool == "3") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-3.pdf"; 
}
		
		
if (bool == "4") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-4.pdf"; 
}

if (bool == "5") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-5.pdf"; 
}
		
if (bool == "6") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-6.pdf"; 
}
		
		
if (bool == "7") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-7.pdf"; 
}
		

if (bool == "8") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-8.pdf"; 
}
				
		
		
if (bool == "9") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-9.pdf"; 
}

if (bool == "10") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-10.pdf"; 
}

if (bool == "11") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-11.pdf"; 
}
		
		
if (bool == "12") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-12.pdf"; 
}
				
if (bool == "13") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-13.pdf"; 
}

if (bool == "14") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-14.pdf"; 
}
		
		
if (bool == "15") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-15.pdf"; 
}

if (bool == "16") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-16.pdf"; 
}
		
if (bool == "17") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-17.pdf"; 
}
		
		
if (bool == "18") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-18.pdf"; 
}
		

if (bool == "19") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-19.pdf"; 
}
				
		
		
if (bool == "20") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-20.pdf"; 
}

if (bool == "21") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-21.pdf"; 
}

if (bool == "22") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-22.pdf"; 
}
		
		
if (bool == "23") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-23.pdf"; 
}
				
if (bool == "24") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-24.pdf"; 
}

if (bool == "25") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-25.pdf"; 
}

if (bool == "26") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-26.pdf"; 
}

if (bool == "27") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-27.pdf"; 
}

if (bool == "28") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-28.pdf"; 
}

if (bool == "29") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-29.pdf"; 
}

if (bool == "30") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-30.pdf"; 
}

if (bool == "31") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-31.pdf"; 
}

if (bool == "32") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-32.pdf"; 
}

if (bool == "33") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-33.pdf"; 
}

if (bool == "34") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-34.pdf"; 
}

if (bool == "35") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-35.pdf"; 
}

if (bool == "36") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-36.pdf"; 
}

if (bool == "37") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-37.pdf"; 
}

if (bool == "38") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-38.pdf"; 
}

if (bool == "39") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-39.pdf"; 
}

if (bool == "40") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-40.pdf"; 
}

if (bool == "41") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-41.pdf"; 
}

if (bool == "42") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-42.pdf"; 
}

if (bool == "43") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-43.pdf"; 
}

if (bool == "44") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-44.pdf"; 
}

if (bool == "45") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-45.pdf"; 
}
if (bool == "46") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-46.pdf"; 
}
if (bool == "47") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-47.pdf"; 
}
if (bool == "48") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-48.pdf"; 
}

if (bool == "49") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-49.pdf"; 
}

if (bool == "50") 
{ 
        var theLink = "http://nmcn.ernet.in/reports/college-50.pdf"; 
}

var chartcheck = "<?php echo $_POST['querylist5']?>";
if (chartcheck == "23" || chartcheck == "24" || chartcheck == "25" || chartcheck == "26" || chartcheck == "30" || chartcheck == "31")
{ 				
		
	window.onload = function() {
	var chart = new CanvasJS.Chart("chartContainer", {
        	animationEnabled: true,
	        title: {
        	        text: "Overall activity completion status of this college"
	        },
                
        	data: [{
                	type: "pie",
	                startAngle: 240,
        	        yValueFormatString: "##0.00\"%\"",
                	indexLabel: "{label} {y}",
                                
	                dataPoints: [
        	                {y: 20, label: "Site Survey Completed", link: theLink},
                	        {y: 65, label: "Activities to be completed"},
                        	{y: 5, label: "Site Survey report submitted", link: theLink},
	                        {y: 10, label: "Site preparation", link: theLink}
        		        ]
	    	    }]
});
	chart.options.data[0].click = function(e){ 
	    var dataSeries = e.dataSeries;
	    var dataPoint = e.dataPoint;
	    var dataPointIndex = e.dataPointIndex;
    
	    if(1)
        	window.open(dataPoint.link,'_blank');  
    
	    for(var i = 0; i < dataSeries.dataPoints.length; i++){
        	    if(i === dataPointIndex){                
                	continue;
	            }
        	    
            	dataSeries.dataPoints[i].exploded = false;            
    		}
	};
		chart.render();
	}
} else {
window.onload = function() {
        var chart = new CanvasJS.Chart("chartContainer", {
                animationEnabled: true,
                title: {
                        text: "Overall activity completion status of this college"
                },
                data: [{
                        type: "pie",
                        startAngle: 240,
                        yValueFormatString: "##0.00\"%\"",
                        indexLabel: "{label} {y}",
                                
                        dataPoints: [
                                {y: 20, label: "Site Survey Completed", link: theLink},
                                {y: 75, label: "Activities to be completed"},
                                {y: 5, label: "Site Survey report submitted", link: theLink}
                                ]
                    }]
});
        chart.options.data[0].click = function(e){ 
            var dataSeries = e.dataSeries;
            var dataPoint = e.dataPoint;
            var dataPointIndex = e.dataPointIndex;
    
            if(1)
                window.open(dataPoint.link,'_blank');  
    
            for(var i = 0; i < dataSeries.dataPoints.length; i++){
                    if(i === dataPointIndex){                
                        continue;
                    }
                    
                dataSeries.dataPoints[i].exploded = false;            
                }
        };
                chart.render();
        }
} //end if else

</script>


</head>
<body>





<div class="row">
  <div class="headercolumn1" style="background-color: #ffffff">
    <a href="http://www.ernet.in/" target="_blank"><img src="images/ernet.png"  style="height:75px;width:115px;"/></a>
        
  </div>
  <div class="headercolumn2" style="background-color: #ffffff">
</br>
    <h2 style="color:black;text-align: center">Dashboard for monitoring e-Classroom infrastructure in 50 Medical Colleges</h2>
  </div>
  <div class="headercolumn3" style="background-color: #ffffff">
<a href="http://www.yash.com" target="_blank" ><img src="images/yash.png" style="height:90px;width:135px;float: right;"/></a>
  </div>
</div>


<div class="topnav" style="align-content: center;">

 <a href="http://nmcn.ernet.in/index.html">Home</a>
  <a href="http://nmcn.ernet.in/about.php">About Us</a>
  <a href="http://nmcn.ernet.in/rrc.html">RRCs</a>
  <a href="http://nmcn.ernet.in/progress-dashboard.php">Dashboard</a>
  <a href="http://nmcn.ernet.in/timelines.php">Timelines</a>
  <a href="http://nmcn.ernet.in/page-3.php">Sort Colleges</a>
  <a href="http://nmcn.ernet.in/logout.php">Logout</a> 
  
</div>

</br>

<h1 style="text-align:center;color:white">Details of College</h1>

<h6 style="text-align:center;color:white">(click college name to view survey report)</h6>
</br>
	<table bordercolor="white" border="1" cellspacing="15">



<thead>
			<tr>
				<th>College ID</th>
				<th>Name of College</th>
				<th>State</th>
				<th>Zone Category</th>
				<th>RRC or NORMAL</th>
				<th>Name of Nodal Officer</th>
			</tr>
		</thead>
		<tbody>
		<?php
		$no 	= 1;
		$total 	= 0;
		while ($row = mysqli_fetch_array($query))
		{
			$id_val = $row["college_id"];
		//	$amount  = $row['amount'] == 0 ? '' : number_format($row['amount']);
			echo "<tr>
					<td>".$row["college_id"]."</td>
					<td><a target='_blank' href='http://nmcn.ernet.in/reports/college-$id_val.pdf'>".$row["name_of_college"]."</td>
					<td>".$row["state"]."</td>
					<td>".$row["zone"]."</td>
					<td>".$row["rrc_or_normal"]."</td>
					<td>".$row["nodal_officer"]."</td>
				</tr>";
//			$total += $row['amount'];
//			$no++;
		}?>
		</tbody>
	</table>

</br>
</br>
</br>

<div class="row">
  <div class="statuscolumn1" >
<h2 style="text-align:center;color:white">Task Completion status</h2>

<?php 
if ($_POST['querylist5'] == "23" || $_POST['querylist5'] == "24" || $_POST['querylist5'] == "25"  || $_POST['querylist5'] == "26" || $_POST['querylist5'] == "30"  || $_POST['querylist5'] == "31" ):
echo
		
'<table align="left" cellspacing="25"> <th>S.No.</th> <th>Activity</th> <th>Completion Status</th>
 <tr><td>1</td><td>Site Survey</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">&#10004;</td></tr>
 <tr><td>2</td><td>Site Survey Report Submitted</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">&#10004;</td></tr>
 <tr><td>3</td><td>Site Preparation</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">&#10004;</td></tr>
 <tr><td>4</td><td>Delivery of Hardware/Software</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">&#10006;</td></tr>
 <tr><td>5</td><td>Hardware Installation</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">&#10006;</td></tr>
 <tr><td>6</td><td>Integration</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">&#10006;</td></tr>
 <tr><td>7</td><td>Capacity Building / Training</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">&#10006;</td></tr>
 <tr><td>8</td><td>Go-Live Sign-Off</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">&#10006;</td></tr>
 <tr><td>9</td><td>Go Live</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">&#10006;</td></tr>
 <tr><td>10</td><td>Deployment of Manpower for O&M</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">&#10006;</td></tr>
</table>';


else:

echo

'<table align="left" cellspacing="25"> <th>S.No.</th> <th>Activity</th> <th>Completion Status</th>
 <tr><td>1</td><td>Site Survey</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">&#10004;</td></tr>
 <tr><td>2</td><td>Site Survey Report Submitted</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">&#10004;</td></tr>
 <tr><td>3</td><td>Site Preparation</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">&#10006;</td></tr>
 <tr><td>4</td><td>Delivery of Hardware/Software</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">&#10006;</td></tr>
 <tr><td>5</td><td>Hardware Installation</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">&#10006;</td></tr>
 <tr><td>6</td><td>Integration</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">&#10006;</td></tr>
 <tr><td>7</td><td>Capacity Building / Training</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">&#10006;</td></tr>
 <tr><td>8</td><td>Go-Live Sign-Off</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">&#10006;</td></tr>
 <tr><td>9</td><td>Go Live</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">&#10006;</td></tr>
 <tr><td>10</td><td>Deployment of Manpower for O&M</td><td align="center" style="text-align:center; font-size:150%; font-weight:bold; color:white;">&#10006;</td></tr>
</table>';

endif;
?>
</br>
</br>
</br>

</br>
</div>

<!--center>
  <div id="chartContainer" style="height: 400px; width: 90%;">
  </div>
</center>
</br--!>
</br>
</br>

	<div class="statuscolumn2" style="background-color: #ffffff;margin-right:20px;">
	<div id="chartContainer" style="height: 450px; width: 100%;"></div>
	<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
	</div>
	</div>
</br>
</br>
</br>
</br>


<div style="height: 80px;width: 100%;postion:absolute;bottom:0">
</br>
</br>
</br>
<h5 style="text-align:center">Designed By:- ERNET India, 5th Floor, Block-I, A Wing, DMRC IT Park Shastri Park, Delhi-110053</h5>

</div>




</body>
</html>


